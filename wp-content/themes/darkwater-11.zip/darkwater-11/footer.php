<div id="footer">
<p>
Copyright &#169; 2007 <?php bloginfo('name'); ?>. Darkwater Theme by <a href="http://antbag.com/">Antbag</a>.
</p>
</div>